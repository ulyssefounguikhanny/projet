@extends('layouts.app')

@section('content')
	Index

@endsection